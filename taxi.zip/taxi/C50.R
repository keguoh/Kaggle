library(C50)
library(parallel)

set.seed(1000)
trn_idx <- sample(1:nrow(dat1), nrow(dat1)/3*2, replace = F)
trn <- dat1[trn_idx, ]
tst <- dat1[-trn_idx, ]

mae <- function(x,y) mean(abs(x-y))

# trnfm <- subset(trn, select=-c(Tip_percent, Total_amount, lpep_pickup_datetime,
#                                Lpep_dropoff_datetime, ID, Tip_amount))
# tstfm <- subset(tst, select=-c(Tip_percent, Total_amount, lpep_pickup_datetime, 
#                                Lpep_dropoff_datetime, ID, Tip_amount))


trnfm <- trn[,c(
  'Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
  'Dropoff_latitude', 'Pickup_day', 'Fare_amount', 'Trip_distance',
  'Duration_min', 'Passenger_count', 'Pickup_hour', 'Coordinate_dist',
  'Speed', 'Pickup_day_of_week', 'Dropoff_hour', 'Extra', 'Pickup_weekend',
  'VendorID', 'Pickup_morning', 'Pickup_daytime',  'Tip_percent_class')
  ]
tstfm <- tst[,c(
  'Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
  'Dropoff_latitude', 'Pickup_day', 'Fare_amount', 'Trip_distance',
  'Duration_min', 'Passenger_count', 'Pickup_hour', 'Coordinate_dist',
  'Speed', 'Pickup_day_of_week', 'Dropoff_hour', 'Extra', 'Pickup_weekend',
  'VendorID', 'Pickup_morning', 'Pickup_daytime',  'Tip_percent_class')
  ]

# temp <- sample(1:nrow(trnfm), 120000, replace = F)
# trn_temp = temp[1:80000]
# val_temp = temp[-(1:80000)]
# trnfm <- trnfm[trn_temp, ]
# tstfm <- trnfm[val_temp, ]

system.time(C50_fit <- C5.0(trnfm[, -ncol(trnfm)],
                trnfm[, ncol(trnfm)], trial = 20))

pred <- as.numeric(paste(
  predict(C50_fit, tstfm[, -ncol(trnfm)], type="class" )))
C50_prob <- predict(C50_fit, tstfm[, -ncol(trnfm)], type="prob" )
(C50imp <- C5imp(C50_fit, metric = "splits", pct = TRUE))

# mae(trn$Tip_percent[val_temp], pred)

mae(tst$Tip_percent, pred)    #4.725358


write.table(cbind(tst$ID, pred, C50_prob),
            file="C50.csv", sep = ',', row.names = F)


