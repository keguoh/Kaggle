

######  3. Feature Selection and Model Building  ######


####  Turn Tip percent into classes  ####
dat1$Tip_percent_class <- cut(dat1$Tip_percent,
                              c(-1,5.362, 13.69533, 18.33333, 21.53846,100),
                              labels = c(0,10.2041,16.6667,20,23.0769))
table(dat1$Tip_percent_class)/nrow(dat1)*100
aggregate(dat1$Tip_percent, list(dat1$Tip_percent_class), median) 


####  Split the raw data into train and test dataset  ####
set.seed(1000)
trn_idx <- sample(1:nrow(dat1), nrow(dat1)/3*2, replace = F)
trn <- dat1[trn_idx, ]
tst <- dat1[-trn_idx, ]

#  temporary smaller data set to train data faster
set.seed(1)
temp <- sample(1:nrow(trn), 30000, replace = F)
trn_temp = trn[temp[1:20000], ]
val_temp = trn[temp[-(1:20000)], ]


####  MAE and Benchmark  ####
mae <- function(x,y) mean(abs(x-y))
tst$pred <- 50/3
mae(tst$pred, tst$Tip_percent) # 4.865767
mae(rep(50/3,nrow(val_temp)), val_temp$Tip_percent)  #4.659616



### ################################## ###
###                                    ###
####  Linear Regression (Lasso/Ridge) ####
###                                    ###
### ################################## ###

library(glmnet)

# Lasso/Ridge
trnfm <- trn_temp[,c('Dropoff_longitude','Pickup_longitude','Dropoff_latitude',
                'Pickup_latitude','Pickup_day','Fare_amount','Passenger_count',
                'Trip_distance','Coordinate_dist','Pickup_day_of_week',
                'Duration_min','Speed','Pickup_hour','Dropoff_hour','Extra',
                'Pickup_weekend','VendorID','Pickup_morning','Pickup_daytime',
                'Pickup_evening', 'Tip_amount')]
tstfm <- val_temp[,c('Dropoff_longitude','Pickup_longitude','Dropoff_latitude',
                'Pickup_latitude','Pickup_day','Fare_amount','Passenger_count',
                'Trip_distance','Coordinate_dist','Pickup_day_of_week',
                'Duration_min','Speed','Pickup_hour','Dropoff_hour','Extra',
                'Pickup_weekend','VendorID','Pickup_morning','Pickup_daytime',
                'Pickup_evening', 'Tip_amount')]

grid =10^seq(10,-2, length =100)
Ridge_fit <- glmnet(as.matrix(trnfm[,-ncol(trnfm)]), as.vector(trnfm[,15]),
                    alpha =1, lambda =grid ,thresh =1e-12)
Ridge_amount_pred <- predict(Ridge_fit, s=100, newx=as.matrix(tstfm[,-10]))
Ridge_pred <- as.vector(Ridge_amount_pred) / (
  as.vector(Ridge_amount_pred) + val_temp$Tolls_amount + val_temp$MTA_tax + 
    val_temp$improvement_surcharge + val_temp$MTA_tax + 
    val_temp$Fare_amount + val_temp$Extra
)
mae(val_temp$Tip_percent, Ridge_pred)  


# Linear regression
lm_fit <- lm(Tip_amount ~., trnfm)
lm_out <- predict(lm_fit, tstfm[,-ncol(tstfm)])
lm_pred <- as.vector(lm_out) / (
  as.vector(lm_out) + val_temp$Tolls_amount + val_temp$MTA_tax + 
    val_temp$improvement_surcharge + val_temp$MTA_tax + 
    val_temp$Fare_amount + val_temp$Extra
)
mae(val_temp$Tip_percent, lm_pred)   



### ###################### ###
###                        ###
####  C50 (Boosting Tree) ####
###                        ###
### ###################### ###


# install.packages("C50")
library(C50)
library(parallel)
trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, Payment_type, 
                                 lpep_pickup_datetime, Lpep_dropoff_datetime, 
                                 ID, Tip_amount))

cv_C50 <- function(t){
  mae <- function(x,y) mean(abs(x-y))
  k=2
  folds=sample(1:k,length(trn_temp),replace=TRUE)
  error <- rep(0,k)
  for(i in 1:k){
    C50_fit <- C50::C5.0(trnfm[folds!=i, -ncol(trnfm)],
                         trnfm[folds!=i, ncol(trnfm)], trial = t)
    C50_pred <- as.numeric(paste(
      C50::predict.C5.0(C50_fit, trnfm[folds==i, -ncol(trnfm)], type="class" )))
    error[i] <- mae(trn$Tip_percent[folds==i], C50_pred)
  }
  return(mean(error))
}
trial=1:3
(no_cores <- detectCores())
cl <- makeCluster(no_cores-1)
clusterExport(cl, c("trnfm", "trn_temp", "val_temp", "trn", "trial"))
te <- parLapply(cl, trial, cv_C50)
unlist(te)
stopCluster(cl)




C50_fit <- C5.0(trnfm[folds!=i, -ncol(trnfm)],
                trnfm[folds!=i, ncol(trnfm)], trial = 20)
C50_pred <- as.numeric(paste(predict(C50_fit, trnfm[val_temp, -ncol(trnfm)], type="class" )))
C50_prob <- predict(C50_fit, trnfm[val_temp, -ncol(trnfm)], type="prob" )
(C50imp <- C5imp(C50_fit, metric = "splits", pct = TRUE))

mae(trn$Tip_percent[val_temp], C50_pred)   #5.04



##################################
#####                        #####
#####  Random Forest (Tree)  #####
#####                        #####
##################################


# rf + caret
library(randomForest)
library(caret)

trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, Payment_type, 
                                 lpep_pickup_datetime, Lpep_dropoff_datetime, 
                                 ID, Tip_amount))
(no_cores <- detectCores())
cl<-makeCluster(no_cores)
registerDoParallel(cl)
system.time(
  rf_model<-train(Tip_percent_class~., data=trnfm[trn_temp, ], method="rf",
                trControl=trainControl(method="cv",number=2),
                prox=TRUE,allowParallel=TRUE)

)
rf_model$finalModel
rf_pred <- as.numeric(paste(predict(rf_model ,newdata = trnfm[val_temp ,])))
rf_prob <- predict(rf_model ,newdata = trnfm[val_temp ,])



# rf

trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, Payment_type,
                                 lpep_pickup_datetime, Lpep_dropoff_datetime,
                                 ID, Tip_amount))

system.time(
  rf_fit <- randomForest(Tip_percent_class ~ ., data=trnfm[trn_temp, ], ntree =100)
)
rf_fit$importance
pred <- as.numeric(paste(stats::predict(rf_fit ,newdata = trnfm[val_temp ,])))
rf_prob <- predict(rf_fit ,newdata = trnfm[val_temp ,], type = 'prob')
mae(trn$Tip_percent[val_temp], pred)   #4.86



#################################
#####                       #####
#####  Nearest neighbour    #####
#####                       #####
#################################
trnfm <- trn[,c('Dropoff_longitude', 'Dropoff_latitude', 'Tip_percent_class')]  #5.25, 5.216, k=20
# 
# trnfm <- trn[,c('Pickup_longitude', 'Pickup_latitude', 'Tip_percent_class')]  #5.04, 6.21, k=20
# 
# trnfm <- trn[,c('Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
#                 'Dropoff_latitude', 'Tip_percent_class')]  #5.01, 5.26, k=20
# 
# trnfm <- trn[,c('Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
#                 'Dropoff_latitude', 'Pickup_day', 'Fare_amount', 'Tip_percent_class')]   #5.06, 5.038, k=20
# 
# trnfm <- trn[,c('Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
#                 'Dropoff_latitude', 'Pickup_day', 'Fare_amount',
#                 'Passenger_count', 'Pickup_hour', 'Coordinate_dist',
#                 'Speed', 'Tip_percent_class')]   #5.07, 5.04, k=20
trnfm <- subset(trn, select = -c(Coordinate_dist,Tip_percent, Total_amount, 
                                 RateCodeID, Store_and_fwd_flag, Payment_type,
                                 lpep_pickup_datetime, improvement_surcharge,
                                 MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount)) # 4.996, 4.937
# kknn
install.packages('kknn')
library(kknn)
kknn_fit <- kknn(Tip_percent_class ~ ., trnfm[trn_temp, ], trnfm[val_temp, ], distance = 1,
kernel = "triangular")
kknn_pred <- as.numeric(paste(kknn_fit$fitted.values))
mae(trn$Tip_percent[val_temp], kknn_pred)  

# knn
library(class)
set.seed(1)
system.time(
  knn_fit <- knn(
    scale(trnfm[trn_temp,-ncol(trnfm)]), 
    scale(trnfm[val_temp,-ncol(trnfm)]), 
    trnfm[trn_temp,ncol(trnfm)], k=20, prob = T)
)
knn_pred <- as.numeric(paste(knn_fit))
mae(trn$Tip_percent[val_temp], knn_pred)  


#cross validation
cv_knn <- function(t){
  mae <- function(x,y) mean(abs(x-y))
  k1=1
  folds=sample(1:k1,length(trn_temp),replace=TRUE)
  error <- rep(0,k1)
  for(i in 1:k1){
    knn_fit <- class::knn(scale(trnfm[folds!=i,-ncol(trnfm)]), 
                          scale(trnfm[folds==i,-ncol(trnfm)]), 
                          trnfm[folds!=i,ncol(trnfm)], k=t)
    knn_pred <- as.numeric(paste(knn_fit))
    error[i] <- mae(trn$Tip_percent[folds==i], knn_pred)
  }
  return(mean(error))
}
trial=1:2
(no_cores <- detectCores())
cl <- makeCluster(no_cores-2)
clusterExport(cl, c("trnfm", "trn_temp", "val_temp", "trn", "trial"))
te <- parLapply(cl, trial, cv_knn)
unlist(te)
stopCluster(cl)




##################################
#####                        #####
#####  LDA  #####
#####                        #####
##################################

library(MASS)
trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, Payment_type, lpep_pickup_datetime, improvement_surcharge, MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))

system.time(
  LDA_fit <- lda(Tip_percent_class ~ ., data = trnfm[trn_temp, ])
)
LDA_output <- predict(LDA_fit, trnfm[val_temp, ])
LDA_prob <- LDA_output$posterior
LDA_pred <- as.numeric(paste(LDA_output$class)) 
mae(trn$Tip_percent[val_temp], LDA_pred)   #4.754


system.time(
  QDA_fit <- qda(Tip_percent_class ~ ., data = trnfm[trn_temp, ])
)
QDA_output <- predict(QDA_fit, trnfm[val_temp, ])
QDA_prob <- QDA_output$posterior
QDA_pred <- as.numeric(paste(QDA_output$class)) 
mae(trn$Tip_percent[val_temp], QDA_pred)   #6.6889



#############################################
#####                                   #####
#####  Multinomial Logistic Regression  #####
#####                                   #####
#############################################



trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, Payment_type, lpep_pickup_datetime, improvement_surcharge, MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))

library(glmnet)
install.packages('doMC')
library(doMC)
registerDoMC(cores=3)

library(parallel)
(no_cores <- detectCores())
cl <- makeCluster(no_cores-1)
system.time(
  mlog_fit <- cv.glmnet(as.matrix(trnfm[trn_temp, -ncol(trnfm)]), 
                        trnfm[trn_temp, ncol(trnfm)], nfolds = 3, type.measure = 'mae',
                        parallel = T, family = 'multinomial')
)
plot(mlog_fit)

mlog_pred <- as.numeric(paste(predict(mlog_fit, newx = as.matrix(trnfm[val_temp, !colnames(trnfm)%in%c('Tip_percent_class')]),
                    type = "class")))
mlog_out <- predict(mlog_fit, newx = as.matrix(trnfm[val_temp, !colnames(trnfm)%in%c('Tip_percent_class')]),
                    type = "response")
mlog_prob <- as.numeric(paste(mlog_out))
head(mlog_prob)
mae(trn$Tip_percent[val_temp], mlog_pred)    #4.725358

x=1

# http://www.ats.ucla.edu/stat/r/dae/mlogit.htm

library(nnet)
trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, Payment_type, lpep_pickup_datetime, improvement_surcharge, MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))

system.time(
  mlognnet_fit <- multinom(Tip_percent_class ~ ., data = trnfm[trn_temp, ])
)
s <- summary(mlognnet_fit)
z <- s$coefficients/s$standard.errors
(p <- (1 - pnorm(abs(z), 0, 1))*2)
mlognnet_prob <- predict(mlognnet_fit, newdata = trnfm[val_temp, ], "probs")
mlognnet_prob_max <- apply(mlognnet_prob, 1, max)
mlognnet_pred <- as.numeric(colnames(mlognnet_prob)[apply(mlognnet_prob, 1, which.max)])

write.table(cbind(mlognnet_prob, mlognnet_pred, trnfm$VendorID[val_temp]),'test.csv', sep = ',', row.names = F)
mae(trn$Tip_percent[val_temp], mlognnet_pred)


# Testing ................
# set.seed(10000)
# temp <- sample(1:nrow(trn), 90000, replace = F)
# trn_temp = temp[1:60000]
# val_temp = temp[-(1:60000)]
# 
# trnfm <- subset(trn, select=-c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, 
#                                Payment_type, lpep_pickup_datetime, improvement_surcharge, 
#                                MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))
# trnfm <- subset(trn, select=-c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, 
#                                Payment_type, lpep_pickup_datetime, improvement_surcharge, 
#                                MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount, Passenger_count,
#                                Pickup_hour, Pickup_day, Pickup_day_of_week, Pickup_weekend,
#                                Dropoff_day, Dropoff_day_of_week, Dropoff_weekend, Speed, Coordinate_dist))
# 
# system.time(
#   mlognnet_fit <- multinom(Tip_percent_class ~ ., data = trnfm[trn_temp, ])
# )
# s <- summary(mlognnet_fit)
# z <- s$coefficients/s$standard.errors
# (p <- (1 - pnorm(abs(z), 0, 1))*2)
# mlognnet_prob <- predict(mlognnet_fit, newdata = trnfm[val_temp, ], "probs")
# mlognnet_prob_max <- apply(mlognnet_prob, 1, max)
# mlognnet_pred <- as.numeric(colnames(mlognnet_prob)[apply(mlognnet_prob, 1, which.max)])
# 
# 
# mae(trn$Tip_percent[val_temp], mlognnet_pred)    
# 
# 
# #  All                  sig
# #  4.747407           4.742672
# #  4.728288          4.725669




#Based on MAE, we use center as the output of each class
#     center      mean  
#MSE  65.89208   65.00713
#MAE  4.804828   4.842471
#     67.291    66.41646
#     4.826      4.862644


##################################
#####       #####
#####  SVM  #####
#####       #####
##################################

install.packages('e1071')
library(e1071)
trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, Payment_type, lpep_pickup_datetime, improvement_surcharge, MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))

svm_fit =svm(Tip_percent_class ~ ., data = trnfm[trn_temp, ], kernel ="linear", cost =10,
             scale =F )

