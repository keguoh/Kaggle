

######  1. Initial Check and Manipulation  ######



# Tip percentage
dat$Tip_percent = dat$Tip_amount/dat$Total_amount*100

# (1) delete empty column
dat$Ehail_fee <- NULL

# (2) create rowID
dat$ID <- 1:nrow(dat)

# (3) imputation for 'zero' location coordinates with mean
dat$Pickup_longitude[dat$Pickup_longitude==0] = mean(dat$Pickup_longitude)
dat$Dropoff_longitude[dat$Dropoff_longitude==0] = mean(dat$Dropoff_longitude)
dat$Pickup_latitude[dat$Pickup_latitude==0] = mean(dat$Pickup_latitude)
dat$Dropoff_latitude[dat$Dropoff_latitude==0] = mean(dat$Dropoff_latitude)

# (4)(5) zero/negative total_amount & non-credit-card type:
# tip_amount for transactions with zero/neg. total_amount & non-credit-card 
table(dat$Tip_amount[dat$Total_amount < 0])
table(dat$Payment_type)
table(dat$Tip_amount[dat$Payment_type == 2])
table(dat$Tip_amount[dat$Payment_type == 3]) 
table(dat$Tip_amount[dat$Payment_type == 4]) 
table(dat$Tip_amount[dat$Payment_type == 5]) 
# delete transactions with zero total_amount and non-credit-card payment type
dat1 <- dat[dat$Total_amount>0, ] 
dat1 <- dat1[dat1$Payment_type == 1, ] 


# (6) Impute Trip_type based on other information
#     and Explore four features 'improvement_surcharge', 'MTA_tax', 
#                               'Trip_type', 'RateCodeID'

dat1[is.na(dat1$Trip_type), c('improvement_surcharge', 'MTA_tax', 
                              'Trip_type', 'RateCodeID')]
dat1$Trip_type[is.na(dat1$Trip_type)] <- 2 # fill the missing value


#MTA_tax: 0 & 0.5
table(dat1$MTA_tax) # only small proportion has zero tax
#improvement_surcharge:  0 & 0.3
table(dat1$improvement_surcharge) # only small proportion has zero surcharge
#Trip_type: 1 & 2
table(dat1$Trip_type)
#RateCodeID: 1 & 5 and others
table(dat1$RateCodeID)

# This four features provide the almost the same information
sum(dat1$improvement_surcharge==0 & dat1$MTA_tax==0 & 
      dat1$Trip_type == 2 & dat1$RateCodeID == 5)




######  2. Feature Engineering  ######


# Only take a small sample, and examine the feature faster and more clearly
set.seed(1)
temp_idx = sample(1:nrow(dat1), 100000, replace = F)


####  (1) Response  ####

#Tip_percent
hist(dat1$Tip_percent, xlim=c(0, 30), breaks = 2000, xlab = 'Tip_percent')
(length(dat1$Tip_percent[dat1$Tip_percent>23 & dat1$Tip_percent<23.1]) + 
    length(dat1$Tip_percent[dat1$Tip_percent>19.5 & dat1$Tip_percent<20.5]) +
    length(dat1$Tip_percent[dat1$Tip_percent>16.4 & dat1$Tip_percent<16.8]) +
    length(dat1$Tip_percent[dat1$Tip_percent>.1 & dat1$Tip_percent<16.4]) +
    length(dat1$Tip_percent[dat1$Tip_percent<.1]))/nrow(dat1)
#Average Tip_Percent grouped by pick-up hours
aggregate(dat1$Tip_percent, factor(dat1$Pickup_hour), mean)


#Tip_amount
hist(dat1$Tip_amount, breaks = 8000, xlim = c(0,10), xlab = 'Tip_amount')
plot(dat1$Tip_amount[temp_idx], dat1$Tip_percent[temp_idx], 
     ylim = c(0,25), xlim = c(0,6)) #People like to tip integers
sum(as.integer(dat1$Tip_amount*100) %% 100 == 0)/nrow(dat1) # 229k tip integer


####  (2) Categorical Variable  ####

# VendorID
boxplot(Tip_percent~VendorID, dat1[temp_idx,], xlab='Vender_ID')
table(dat1$VendorID)/nrow(dat1)*100
aggregate(dat1$Tip_percent, list(dat1$VendorID), median) 


#Store_and_fwd_flag
boxplot(Tip_percent~Store_and_fwd_flag, dat1[temp_idx,], 
        xlab='Store_and_fwd_flag')
table(dat1$Store_and_fwd_flag)             #0.465% of Y
aggregate(dat1$Tip_percent, list(dat1$Store_and_fwd_flag), median)

#Passenger_count
boxplot(Tip_percent~Passenger_count, dat1[temp_idx,], xlab='Passenger_count')
table(dat1$Passenger_count)
aggregate(dat1$Tip_percent, list(dat1$Passenger_count), median) #no pattern

#Trip_type
boxplot(Tip_percent~Trip_type, dat1[temp_idx,], xlab='Trip_type')
table(dat1$Trip_type)

#RateCodeID
boxplot(Tip_percent~RateCodeID, dat1[temp_idx,], xlab='RateCodeID')
table(dat1$RateCodeID)

#Extra
boxplot(Tip_percent~Extra, dat1[temp_idx,], xlab='Extra')
table(dat1$Extra)
aggregate(dat1$Tip_percent, list(dat1$Extra), mean) #no pattern


####  (3) Continuous Variables   ####

#Trip_distance
hist(dat1$Trip_distance, breaks = 200, xlim = c(0,25))
temp_idx = sample(1:nrow(dat1), 10000, replace = F)
plot(dat1$Trip_distance[temp_idx], dat1$Tip_percent[temp_idx],
     ylim = c(0,25), xlim = c(0,20), color='red',
     main = 'Relation between Trip Distance and Tip Percentage', 
     xlab = 'Trip Distance', ylab = 'Tip Percentage') #negative related
abline(lm(Tip_percent~Trip_distance, dat1), col='red', lwd=2)

# Fare_amount
hist(dat1$Fare_amount, breaks = 200, xlim = c(0,50))
plot(dat1$Fare_amount[temp_idx], dat1$Tip_percent[temp_idx], 
     ylim = c(0,25), xlim = c(0,50), xlab = 'Fare Amount') 
abline(lm(Tip_percent~Fare_amount, dat1), col='red', lwd=2)
#Tolls_amount
hist(dat1$Tolls_amount, breaks = 200, xlim = c(0,50))
plot(dat1$Tolls_amount[temp_idx], dat1$Tip_percent[temp_idx], 
     ylim = c(0,25), xlim = c(0,15), xlab = 'Tolls Amount') 
abline(lm(Tip_percent~Tolls_amount, dat1), col='red', lwd=2)


####  (4) Location  ####
Pickup_coordinates <- dat1[, c('Pickup_longitude', 'Pickup_latitude')]
Pickup_km <- kmeans(Pickup_coordinates, 15, nstart=10)
plot(Pickup_coordinates, col=(Pickup_km$cluster),
     main="K-Means Clustering for Pickup Locations", xlab="Pickup Locations",
     xlim=c(-74.1,-73.7), ylim=c(40.55,40.95), pch=20, cex=.8)

Dropoff_coordinates <- dat1[, c('Dropoff_longitude', 'Dropoff_latitude')]
Dropoff_km <- kmeans(Dropoff_coordinates, 15, nstart=10)
plot(Dropoff_coordinates, col=(Dropoff_km$cluster),
     main="K-Means Clustering for Dropoff Locations", xlab="Dropoff Locations",
     xlim=c(-74.1,-73.7), ylim=c(40.55,40.95), pch=20, cex=.8)

Clusters <- model.matrix(
  y ~ pickup + dropoff, 
  data = data.frame(y=rep(1, nrow(dat1)), pickup=factor(Pickup_km$cluster),
                    dropoff=factor(Dropoff_km$cluster)))[,-1]
# Add cluster columns to the feature matrix
dat1 = cbind(dat1, Clusters)

# Coordinate Distance
library(geosphere)  # used to compute geographical distance
dat1$Coordinate_dist <- apply(
  dat1[, c('Pickup_longitude', 'Pickup_latitude', 
           'Dropoff_longitude', 'Dropoff_latitude')], 
  1, function(x){geosphere::distHaversine(x[1:2], x[3:4])})/1609.344 # mile

####  (5) Time and Speed  #####

pickup_time <- as.POSIXct(dat1$lpep_pickup_datetime, 
                          format='%Y-%m-%d %H:%M:%S')
dat1$Pickup_hour <- as.numeric(format(pickup_time, '%H'))
dat1$Pickup_day <- as.numeric(format(pickup_time, '%d'))
dat1$Pickup_day_of_week <- dat1$Pickup_day %% 7 + 1
dat1$Pickup_weekend <- floor(dat1$Pickup_day_of_week / 6)

dropoff_time <- as.POSIXct(dat1$Lpep_dropoff_datetime, 
                           format='%Y-%m-%d %H:%M:%S')
dat1$Dropoff_hour <- as.numeric(format(dropoff_time, '%H'))
dat1$Dropoff_day <- as.numeric(format(dropoff_time, '%d'))
dat1$Dropoff_day_of_week <- dat1$Dropoff_day %% 7 + 1
dat1$Dropoff_weekend <- floor(dat1$Dropoff_day_of_week / 6)

dat1$Pickup_morning <- as.numeric(dat1$Pickup_hour > 4 &
                                    dat1$Pickup_hour <= 9)
dat1$Pickup_daytime <- as.numeric(dat1$Pickup_hour > 9 & 
                                    dat1$Pickup_hour <= 18)
dat1$Pickup_evening <- as.numeric(dat1$Pickup_hour > 18 & 
                                    dat1$Pickup_hour < 24)
dat1$Pickup_night <- as.numeric(dat1$Pickup_hour >= 0 & 
                                  dat1$Pickup_hour < 4)
dat1$Dropoff_morning <- as.numeric(dat1$Dropoff_hour > 4 & 
                                     dat1$Dropoff_hour <= 9)
dat1$Dropoff_daytime <- as.numeric(dat1$Dropoff_hour > 9 & 
                                     dat1$Dropoff_hour <= 18)
dat1$Dropoff_evening <- as.numeric(dat1$Dropoff_hour > 18 & 
                                     dat1$Dropoff_hour < 24)
dat1$Dropoff_night <- as.numeric(dat1$Dropoff_hour >= 0 & 
                                   dat1$Dropoff_hour < 4)

dat1$Duration_min <- round((as.vector(dropoff_time) 
                            - as.vector(pickup_time))/60, 3)
dat1$Speed <- dat1$Trip_distance / dat1$Duration_min
dat1$Speed[dat1$Duration_min==0] = 0
