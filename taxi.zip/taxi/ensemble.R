mlognnet <- read.csv('C:/Users/Keguo/Desktop/mlognnet.csv', header=T, sep = ',')
mlognnet2 <- read.csv('C:/Users/Keguo/Dropbox/taxi/mlognnet2.csv', header=T, sep = ',')
rf <- read.csv('C:/Users/Keguo/Dropbox/taxi/rf.csv', header=T, sep = ',')
LDA <- read.csv('C:/Users/Keguo/Desktop/LDA.csv', header=T, sep = ',')
LDA2 <- read.csv('C:/Users/Keguo/Dropbox/taxi/LDA2.csv', header=T, sep = ',')
head(mlognnet)
head(rf)
head(LDA2)
head(x)
mae(tst$Tip_percent, mlognnet[,2])   #4.86
mae(tst$Tip_percent, mlognnet2[,2])   #4.86
mae(tst$Tip_percent, LDA[,2])   #4.86
mae(tst$Tip_percent, rf[,2])   #4.86

ensem <- function(a,b,weight_b){
  tst_err = rep(0, length(weight_b))
  for(i in weight_b){
    x <- (1-i/100) * a[,3:7] + i/100 *b[,3:7]
    colnames(x) <- c('0','10.724','16.6667','20','23.0769')
    pred <- as.numeric(paste(apply(x, 1, function(t) colnames(x)[which.max(t)])))
    tst_err[i] <- mae(tst$Tip_percent, pred)
  }
  return(tst_err)
}

a <- ensem(mlognnet, LDA, seq(1,3,2))
a

err <- matrix(0, 10,10)
for (i in seq(0,100,10)){
  for(j in seq(0,100-i,10)){
    x <- (1-(i+j)/100)* mlognnet[,3:7] + (i/100)* LDA[,3:7] + (j/100)*rf[,3:7]
    
    colnames(x) <- c('0','10.724','16.6667','20','23.0769')
    pred <- as.numeric(paste(apply(x, 1, function(t) colnames(x)[which.max(t)])))
    print(mae(tst$Tip_percent, pred))   #4.86
    err[i/10,j/10] <- mae(tst$Tip_percent, pred)
    
  }
}



err_5 <- rep(0,101)
for (i in seq(0,100,1)){
  x <- (1-i/100)* LDA2[,3:7] + (i/100)*mlognnet2[,3:7]
  colnames(x) <- c('0','10.724','16.6667','20','23.0769')
  pred <- as.numeric(paste(apply(x, 1, function(t) colnames(x)[which.max(t)])))
  print(mae(tst$Tip_percent, pred))   #4.86
  err_5[i+1] <- mae(tst$Tip_percent, pred)
}

err_4 <- rep(0,101)
for (i in seq(0,100,1)){
  x <- (1-i/100)* LDA2[,3:7] + (i/100)*rf[,3:7]
  colnames(x) <- c('0','10.724','16.6667','20','23.0769')
  pred <- as.numeric(paste(apply(x, 1, function(t) colnames(x)[which.max(t)])))
  print(mae(tst$Tip_percent, pred))   #4.86
  err_4[i+1] <- mae(tst$Tip_percent, pred)
}

err_3 <- rep(0,101)
for (i in seq(0,100,1)){
  x <- (1-i/100)* mlognnet2[,3:7] + (i/100)*rf[,3:7]
  colnames(x) <- c('0','10.724','16.6667','20','23.0769')
  pred <- as.numeric(paste(apply(x, 1, function(t) colnames(x)[which.max(t)])))
  print(mae(tst$Tip_percent, pred))   #4.86
  err_3[i+1] <- mae(tst$Tip_percent, pred)
}

plot(1, type = 'n', xlab = 'Weight of randomForest method', 
     ylab = 'test error', xlim = c(0,100), ylim = c(4.64,4.85))
lines(0:100, err_3, lwd=2, col='blue')
lines(0:100, err_4, lwd=2, col='red')
abline(v=which.min(err_3)-1, col='blue')
legend(50,4.85,c('randomForest + multi-logistic', 'randomForest + LDA'),
       lwd=c(2,2),col=c('blue','red')) # gives the legend lines the correct color and width


# err_2 <- rep(0,101) #4.64
# for (i in seq(0,100,1)){
#   x <- (1-i/100)* mlognnet[,3:7] + (i/100)*rf[,3:7]
#   colnames(x) <- c('0','10.724','16.6667','20','23.0769')
#   pred <- as.numeric(paste(apply(x, 1, function(t) colnames(x)[which.max(t)])))
#   print(mae(tst$Tip_percent, pred))   #4.86
#   err_2[i+1] <- mae(tst$Tip_percent, pred)
# }
# plot(0:100, err_3, type = 'l', xlab = 'Weight of randomForest method', ylab = 'test error')
# abline(v=which.min(err_3)-1)
# 
