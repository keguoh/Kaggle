library(C50)
library(parallel)
set.seed(1000)
dat1$Pickup_morning <- as.numeric(dat1$Pickup_hour > 4 & dat1$Pickup_hour <= 9)
dat1$Pickup_daytime <- as.numeric(dat1$Pickup_hour > 9 & dat1$Pickup_hour <= 18)
dat1$Pickup_evening <- as.numeric(dat1$Pickup_hour > 18 & dat1$Pickup_hour < 24)
dat1$Pickup_night <- as.numeric(dat1$Pickup_hour >= 0 & dat1$Pickup_hour < 4)
dat1$Dropoff_morning <- as.numeric(dat1$Dropoff_hour > 4 & dat1$Dropoff_hour <= 9)
dat1$Dropoff_daytime <- as.numeric(dat1$Dropoff_hour > 9 & dat1$Dropoff_hour <= 18)
dat1$Dropoff_evening <- as.numeric(dat1$Dropoff_hour > 18 & dat1$Dropoff_hour < 24)
dat1$Dropoff_night <- as.numeric(dat1$Dropoff_hour >= 0 & dat1$Dropoff_hour < 4)
dat1$Tip_percent_class <- NULL
dat1$Tip_percent_class <- cut(dat1$Tip_percent,
                              c(-1,5.362, 13.69533, 18.33333, 21.53846,100),
                              labels = c(0,10.724,16.6667,20,23.0769))

trn_idx <- sample(1:nrow(dat1), nrow(dat1)/3*2, replace = F)
trn <- dat1[trn_idx, ]
tst <- dat1[-trn_idx, ]

mae <- function(x,y) mean(abs(x-y))


trnfm <- trn[,c('Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
                'Dropoff_latitude', 'Pickup_day', 'Fare_amount', 'Trip_distance',
                'Duration_min', 'Passenger_count', 'Pickup_hour', 'Coordinate_dist',
                'Speed', 'Pickup_day_of_week', 'Dropoff_hour', 'Extra', 
                'Pickup_weekend', 'VendorID', 'Pickup_morning', 'Pickup_daytime',
                'Pickup_evening', 'Pickup_night', 'Dropoff_morning', 'Dropoff_daytime', 
                'Dropoff_evening', 'Dropoff_night', 'Tip_percent_class')]
tstfm <- tst[,c('Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
                'Dropoff_latitude', 'Pickup_day', 'Fare_amount', 'Trip_distance',
                'Duration_min', 'Passenger_count', 'Pickup_hour', 'Coordinate_dist',
                'Speed', 'Pickup_day_of_week', 'Dropoff_hour', 'Extra', 
                'Pickup_weekend', 'VendorID', 'Pickup_morning', 'Pickup_daytime',
                'Pickup_evening', 'Pickup_night', 'Dropoff_morning', 'Dropoff_daytime', 
                'Dropoff_evening', 'Dropoff_night', 'Tip_percent_class')]

cv_C50 <- function(t){
  mae <- function(x,y) mean(abs(x-y))
  k=5
  folds=sample(1:k,nrow(trn),replace=TRUE)
  error <- rep(0,k)
  for(i in 1:k){
    C50_fit <- C50::C5.0(trnfm[folds!=i, -ncol(trnfm)],
                         trnfm[folds!=i, ncol(trnfm)], trial = t)
    C50_pred <- as.numeric(paste(
      C50::predict.C5.0(C50_fit, trnfm[folds==i, -ncol(trnfm)], type="class" )))
    error[i] <- mae(trn$Tip_percent[folds==i], C50_pred)
  }
  return(mean(error))
}
trial=as.integer(seq(5,40,length.out = 16))
(length(trial))
(no_cores <- detectCores())
cl <- makeCluster(no_cores)
clusterExport(cl, c("trnfm", "trn", "trial"))
te <- parLapply(cl, trial, cv_C50)
(unlist(te))
stopCluster(cl)
