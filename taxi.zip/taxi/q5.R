#q5

####  (1)  Compute average speed  ####
pickup_time <- as.POSIXct(dat$lpep_pickup_datetime, 
                          format='%Y-%m-%d %H:%M:%S')
dropoff_time <- as.POSIXct(dat$Lpep_dropoff_datetime, 
                           format='%Y-%m-%d %H:%M:%S')
dat$Duration_hour <- round((as.vector(dropoff_time) 
                            - as.vector(pickup_time))/3600, 3)
dat$Speed_mph <- dat$Trip_distance / dat$Duration_hour


####   Analysis of average speed over 5 weeks  ####

# create a column to label which week the trip belongs to
dat$Pickup_day_of_month <- as.numeric(format(pickup_time, '%d'))
dat$Pickup_day_of_week <- dat$Pickup_day_of_month %% 7 + 1
dat$Pickup_week_of_month <- (dat$Pickup_day_of_month + 1) %/% 7 + 1

# Delete errors and outliers
head(dat[is.nan(dat$Speed_mph), c('Trip_distance', "Duration_hour")])
head(dat[is.infinite(dat$Speed_mph), c('Trip_distance', "Duration_hour")])
dat2 <- dat[dat$Duration_hour>0 & dat$Speed_mph>0 & dat$Speed_mph<120, ]

# create a small sample, for fast processing
set.seed(1)
temp_idx = sample(1:nrow(dat), 10000, replace = F)
dat2_temp <- dat2[temp_idx, ]

# Boxplot
boxplot(Speed_mph ~ factor(Pickup_week_of_month), dat2_temp, ylim = c(0,60),
        xlab = 'Week of the Month', ylab = 'Average (m/h)')

# Fit the ANOVA
dat2$W <- factor(dat2$Pickup_week_of_month)
dat2$D <- factor(dat2$Pickup_day_of_week)
dat2_temp <- dat2[temp_idx, ]

lm_speed <- lm(Speed_mph ~ 0 + W + D + W:D, dat2)
summary(lm_speed)
anova(lm_speed)
plot(lm_speed)

hist(dat2_temp$Speed_mph, breaks = 2000, xlim = c(0,40), xlab = 'Speed (m/h)')

# Log Transformation
dat2$Log_speed <- log(dat2$Speed_mph)
dat2_temp <- dat2[temp_idx, ]
hist(dat2_temp$Log_speed, breaks = 1000, xlim = c(0,5))
lm_logspeed <- lm(Log_speed ~ 0 + W + D + W:D, dat2)
summary(lm_logspeed)
anova(lm_logspeed)
plot(lm_logspeed)




####  (2)  ####

Pickup_min_of_hour <- as.numeric(format(pickup_time, '%M'))
Pickup_hour_of_day <- as.numeric(format(pickup_time, '%H'))
dat$Pickup_min_of_day <- Pickup_hour_of_day*60 + Pickup_min_of_hour
dat$Pickup_min_of_day_in_hour <- dat$Pickup_min_of_day / 60
dat2 <- dat[dat$Duration_hour>0 & dat$Speed_mph>0 & dat$Speed_mph < 120, ]
mean_speed_by_min_of_day <- aggregate(dat2$Speed_mph, list(dat2$Pickup_min_of_day), mean)


set.seed(1)
temp_idx = sample(1:nrow(dat2), 20000, replace = F)
dat2_temp <- dat2[temp_idx, ]
library(splines)
fit=lm(Speed_mph~bs(Pickup_min_of_day_in_hour,knots=c(4.3,5.6,6.7,7.9,10.3,17.2)),data=dat2)
time_lim <- range(dat2$Pickup_min_of_day/60)
time_grid <- seq(0,24,.1)
pred=predict(fit,newdata=list(Pickup_min_of_day_in_hour=time_grid),se=T)
plot(dat2_temp$Pickup_min_of_day_in_hour, dat2_temp$Speed_mph, ylim = c(0,40),
     col='grey', pch=20, cex=.8, xlab = 'Time of Day (h)', ylab = 'Speed (m/h)')
lines(time_grid,pred$fit,lwd=2, col='red', type='l')
lines(time_grid,pred$fit+2*pred$se,lty="dashed", col='red', lwd=2)
lines(time_grid,pred$fit-2*pred$se,lty="dashed", col='red', lwd=2)
lines((mean_speed_by_min_of_day$Group.1+1)/60, 
      mean_speed_by_min_of_day$x, type = 'l', lwd=1)
legend(16,40,c('Spline Regression', 'Mean Speed over time'), 
       col = c('red','black'), lwd = 2)
