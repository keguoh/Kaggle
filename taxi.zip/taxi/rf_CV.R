library(randomForest)
library(caret)
library(parallel)
library(doParallel)
library(pROC)


set.seed(1000)
dat1$Pickup_morning <- as.numeric(dat1$Pickup_hour > 4 & dat1$Pickup_hour <= 9)
dat1$Pickup_daytime <- as.numeric(dat1$Pickup_hour > 9 & dat1$Pickup_hour <= 18)
dat1$Pickup_evening <- as.numeric(dat1$Pickup_hour > 18 & dat1$Pickup_hour < 24)
dat1$Pickup_night <- as.numeric(dat1$Pickup_hour >= 0 & dat1$Pickup_hour < 4)
dat1$Dropoff_morning <- as.numeric(dat1$Dropoff_hour > 4 & dat1$Dropoff_hour <= 9)
dat1$Dropoff_daytime <- as.numeric(dat1$Dropoff_hour > 9 & dat1$Dropoff_hour <= 18)
dat1$Dropoff_evening <- as.numeric(dat1$Dropoff_hour > 18 & dat1$Dropoff_hour < 24)
dat1$Dropoff_night <- as.numeric(dat1$Dropoff_hour >= 0 & dat1$Dropoff_hour < 4)
dat1$Tip_percent_class <- NULL
dat1$Tip_percent_class <- cut(dat1$Tip_percent,
                              c(-1,5.362, 13.69533, 18.33333, 21.53846,100),
                              labels = c(0,10.724,16.6667,20,23.0769))

trn_idx <- sample(1:nrow(dat1), nrow(dat1)/3*2, replace = F)
trn <- dat1[trn_idx, ]
tst <- dat1[-trn_idx, ]

mae <- function(x,y) mean(abs(x-y))


trnfm <- trn[,c('Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
                'Dropoff_latitude', 'Pickup_day', 'Fare_amount', 'Trip_distance',
                'Duration_min', 'Passenger_count', 'Pickup_hour', 'Coordinate_dist',
                'Speed', 'Pickup_day_of_week', 'Dropoff_hour', 'Extra', 
                'Pickup_weekend', 'VendorID', 'Pickup_morning', 'Pickup_daytime',
                'Tip_percent_class')]
tstfm <- tst[,c('Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
                'Dropoff_latitude', 'Pickup_day', 'Fare_amount', 'Trip_distance',
                'Duration_min', 'Passenger_count', 'Pickup_hour', 'Coordinate_dist',
                'Speed', 'Pickup_day_of_week', 'Dropoff_hour', 'Extra', 
                'Pickup_weekend', 'VendorID', 'Pickup_morning', 'Pickup_daytime',
                'Tip_percent_class')]
mae <- function(x,y) mean(abs(x-y))
k=2
folds=sample(1:k,nrow(trn),replace=TRUE)
t = seq(50,300,50)
error <- matrix(0,2,length(t))
for(j in t){
  for(i in 1:k){
    system.time(
      rf_fit <- randomForest::randomForest(Tip_percent_class ~ ., 
                                           data=trnfm[folds!=i, ], ntree =j)
    )
    rf_pred <- as.numeric(paste(predict(
      rf_fit ,newdata = trnfm[folds==i, ]
    )))
    error[i,which(t==j)] <- mae(trn$Tip_percent[folds==i], rf_pred)
  }
}

(error)
(apply(error, 2, mean))

# 
# cv_rf <- function(t){
#   mae <- function(x,y) mean(abs(x-y))
#   k=5
#   folds=sample(1:k,nrow(trn),replace=TRUE)
#   error <- rep(0,k)
#   for(i in 1:k){
#     system.time(
#       rf_fit <- randomForest::randomForest(Tip_percent_class ~ ., 
#                                            data=trnfm[folds!=i, ], ntree =t)
#     )
#     rf_pred <- as.numeric(paste(randomForest::predict.randomForest(
#       rf_fit ,newdata = trnfm[folds==i, ]
#       )))
#     error[i] <- mae(trn$Tip_percent[folds==i], rf_pred)
#   }
#   return(mean(error))
# }
# save.image()
# trial=as.integer(seq(10,500,length.out = 16))
# (length(trial))
# (no_cores <- detectCores())
# cl <- makeCluster(no_cores)
# clusterExport(cl, c("trnfm", "trn", "trial"))
# te <- parLapply(cl, trial, cv_rf)
# (unlist(te))
# stopCluster(cl)