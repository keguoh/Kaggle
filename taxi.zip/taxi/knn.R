library(class)
set.seed(1000)
trn_idx <- sample(1:nrow(dat1), nrow(dat1)/3*2, replace = F)
trn <- dat1[trn_idx, ]
tst <- dat1[-trn_idx, ]

#MSE
mae <- function(x,y) mean(abs(x-y))
#Benchmark
tst$pred <- 50/3
(mae(tst$pred, tst$Tip_percent)) # 4.865767


trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, Payment_type, lpep_pickup_datetime, improvement_surcharge, MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))
tstfm <- subset(tst, select = -c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, Payment_type, lpep_pickup_datetime, improvement_surcharge, MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))

knn_fit <- class::knn(scale(trnfm[,-ncol(trnfm)]), 
                      scale(tstfm[,-ncol(tstfm)]), 
                      trnfm[,ncol(trnfm)], k=20, prob = T)
knn_pred <- as.numeric(paste(knn_fit))
(mae(tst$Tip_percent, pred))
knn_prob <- attributes(knn_fit)


write.table(cbind(tst$ID, pred, knn_prob),
            file="mlognnet.csv", sep = ',', row.names = F)
# write.table(cbind(data.frame(ID=tst$ID[tst_temp]), mlog_prob), 
#             file="mlog.csv", sep = ',', row.names = F)
