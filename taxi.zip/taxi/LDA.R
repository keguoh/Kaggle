library(MASS)
set.seed(1000)
trn_idx <- sample(1:nrow(dat1), nrow(dat1)/3*2, replace = F)
trn <- dat1[trn_idx, ]
tst <- dat1[-trn_idx, ]

mae <- function(x,y) mean(abs(x-y))

# trnfm <- subset(trn, select=-c(Tip_percent, Total_amount, lpep_pickup_datetime, 
#                                Lpep_dropoff_datetime, ID, Tip_amount, 
#                                Payment_type))
# tstfm <- subset(tst, select=-c(Tip_percent, Total_amount, lpep_pickup_datetime,
#                                Lpep_dropoff_datetime, ID, Tip_amount, 
#                                Payment_type))

# trnfm <- trn[,c('Dropoff_longitude','Pickup_longitude','Dropoff_latitude',
#                 'Pickup_latitude','Pickup_day','Fare_amount','Passenger_count',
#                 'Trip_distance','Coordinate_dist','Pickup_day_of_week',
#                 'Duration_min','Speed','Pickup_hour','Dropoff_hour','Extra',
#                 'Pickup_weekend','VendorID','Pickup_morning','Pickup_daytime',
#                 'Pickup_evening', 'Tip_percent_class')]
# tstfm <- tst[,c('Dropoff_longitude','Pickup_longitude','Dropoff_latitude',
#                 'Pickup_latitude','Pickup_day','Fare_amount','Passenger_count',
#                 'Trip_distance','Coordinate_dist','Pickup_day_of_week',
#                 'Duration_min','Speed','Pickup_hour','Dropoff_hour','Extra',
#                 'Pickup_weekend','VendorID','Pickup_morning','Pickup_daytime',
#                 'Pickup_evening', 'Tip_percent_class')]



trnfm <- trn[,c('Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
                'Dropoff_latitude', 'Pickup_day', 'Fare_amount', 'Trip_distance',
                'Duration_min', 'Passenger_count', 'Pickup_hour', 'Coordinate_dist',
                'Speed', 'Pickup_day_of_week', 'Dropoff_hour', 'Extra',
                'Pickup_weekend', 'VendorID', 'Pickup_morning', 'Pickup_daytime',
                'Tip_percent_class')]
tstfm <- tst[,c('Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
                'Dropoff_latitude', 'Pickup_day', 'Fare_amount', 'Trip_distance',
                'Duration_min', 'Passenger_count', 'Pickup_hour', 'Coordinate_dist',
                'Speed', 'Pickup_day_of_week', 'Dropoff_hour', 'Extra',
                'Pickup_weekend', 'VendorID', 'Pickup_morning', 'Pickup_daytime',
                'Tip_percent_class')]

system.time(
  LDA_fit <- lda(Tip_percent_class ~ ., data = trnfm)
)
LDA_output <- predict(LDA_fit, tstfm)
LDA_prob <- LDA_output$posterior
pred <- as.numeric(paste(LDA_output$class)) 
mae(tst$Tip_percent, pred)   #4.754


write.table(cbind(tst$ID, pred, LDA_prob),
            file="LDA.csv", sep = ',', row.names = F)
