

######  quesiton 1  ######



#load the data
library(readr)
dat <- read_csv('C:/Users/Keguo/Dropbox/taxi/green_tripdata_2015-09.csv')

# dimension of the set
dim(dat)

# check the missing values
apply(dat, 2, function(x) sum(is.na(x)))



######  question2  ######



# some features of Trip Distance
head(sort(dat$Trip_distance, decreasing = T),10)
median(dat$Trip_distance)
mean(dat$Trip_distance)
sqrt(var(dat$Trip_distance))

# quantile
quantile(dat$Trip_distance,probs = c(0,5,25,50,75,95,100)/100)

# Histogram of the trip distance with the x-axis [0,100]
library(ggplot2)
ggplot(dat, aes(x=Trip_distance)) +
  geom_histogram(bins = 1500, colour='black') + 
  coord_cartesian(xlim = c(0, 20)) +
  ggtitle('Histogram of Trip Distance') +
  labs(x='Trip Distance', y='Count')
  



######  question3  ######


###  Part 1  ###


# create Pickup_hour column
pickup_time <- as.POSIXct(dat$lpep_pickup_datetime, format='%Y-%m-%d %H:%M:%S')
dat$Pickup_hour <- as.numeric(format(pickup_time, '%H'))

# compute mean/median grouped by hour
(Mean_group_by_hour <- 
    aggregate(dat[,'Trip_distance'], list(dat$Pickup_hour), mean))
(Median_group_by_hour <- 
    aggregate(dat[,'Trip_distance'], list(dat$Pickup_hour), median))

# Create Mean/Median Trip Distance Grouped by Pickup Hour
M <- data.frame(hour=factor(c(Mean_group_by_hour$Group.1, 
                              Median_group_by_hour$Group.1), ordered=T), 
                 quantity=c(rep('mean', nrow(Mean_group_by_hour)), 
                            rep('median', nrow(Median_group_by_hour))), 
                 values=c(round(Mean_group_by_hour$Trip_distance,2), 
                          Median_group_by_hour$Trip_distance))
ggplot(data = M, aes(x=hour, y=values, fill=quantity)) + 
  geom_bar(stat = "identity", colour="black", position = position_dodge()) +
  geom_text(aes(label=values), vjust=-0.5) +
  ggtitle('Mean/Median Trip Distance Grouped by Pickup Hour') +
  labs(x='Pickup Hour', y='Trip Distance')


###  Part 2  ###


#  JFK  #


# quantile of longitude and latitude
quantile(dat$Pickup_longitude)
quantile(dat$Pickup_latitude)

# Scatter plot of pickup and dropoff locations
plot(x=dat$Pickup_longitude, y=dat$Pickup_latitude, pch=20, cex=.8,
     xlim = c(-74.3,-73.6), ylim = c(40.5,41), xlab = 'Pickup Locations')
plot(x=dat$Dropoff_longitude, y=dat$Dropoff_latitude, pch=20, cex=.8,
     xlim = c(-74.3,-73.6), ylim = c(40.5,41), xlab = 'Dropoff Locations')

# Indice for JFK locations
JFK_pickup = which(dat$Pickup_longitude < -73.7737 & 
                     dat$Pickup_longitude > -73.7936 & 
                     dat$Pickup_latitude > 40.6401 & 
                     dat$Pickup_latitude < 40.6506)
JFK_dropoff = which(dat$Dropoff_longitude < -73.7737 &
                      dat$Dropoff_longitude > -73.7936 &
                      dat$Dropoff_latitude > 40.6401 & 
                      dat$Dropoff_latitude < 40.6506)

# Number of trips originate or terminate at JFK
length(JFK_dropoff)
length(JFK_pickup)

# Unions of pickup and dropoff (avoid counting the same trip twice)
dat_JFK = dat[union(JFK_pickup, JFK_dropoff),]

# Plot points at JFK
plot(x=dat$Pickup_longitude[JFK_pickup], y=dat$Pickup_latitude[JFK_pickup], 
     main = 'Pickup Locations in JFK')
plot(x=dat$Dropoff_longitude[JFK_dropoff], y=dat$Dropoff_latitude[JFK_dropoff], 
     main = 'Dropoff Locations in JFK')


#  LGA  #


# Plot trips in the whole LGA area
LGA_pickup_area = which(dat$Pickup_longitude > -73.8912 
                        & dat$Pickup_longitude < -73.8554
                        & dat$Pickup_latitude > 40.7660
                        & dat$Pickup_latitude < 40.7752)
LGA_dropoff_area = which(dat$Dropoff_longitude > -73.8912 
                         & dat$Dropoff_longitude < -73.8554
                         & dat$Dropoff_latitude > 40.7660 
                         & dat$Dropoff_latitude < 40.7752)
plot(x=dat$Pickup_longitude[LGA_pickup_area],
     y=dat$Pickup_latitude[LGA_pickup_area], 
     main = 'Pickup Locations in LGA', 
     xlim = c(-73.8912,-73.8554), ylim = c(40.7660, 40.7752))
plot(x=dat$Dropoff_longitude[LGA_dropoff_area], 
     y=dat$Dropoff_latitude[LGA_dropoff_area], 
     main = 'Dropoff Locations in LGA', 
     xlim = c(-73.8912,-73.8554), ylim = c(40.7660, 40.7752))


# Indice for LGA locations
LGA_pickup = which(
  (dat$Pickup_longitude > -73.8869 & dat$Pickup_longitude < -73.8838  
   & dat$Pickup_latitude > 40.7699 & dat$Pickup_latitude < 40.7752)|
    (dat$Pickup_longitude > -73.8802 & dat$Pickup_longitude < -73.8554  
     & dat$Pickup_latitude > 40.7711 & dat$Pickup_latitude < 40.7752)|
    (dat$Pickup_longitude > -73.8678 & dat$Pickup_longitude < -73.8554  
     & dat$Pickup_latitude > 40.7691 & dat$Pickup_latitude < 40.7752)|
    (dat$Pickup_longitude > -73.8633 & dat$Pickup_longitude < -73.8554  
     & dat$Pickup_latitude > 40.7668 & dat$Pickup_latitude < 40.7752)) 
LGA_dropoff = which(
  (dat$Dropoff_longitude > -73.8869 & dat$Dropoff_longitude < -73.8838  
   & dat$Dropoff_latitude > 40.7699 & dat$Dropoff_latitude < 40.7752)|
    (dat$Dropoff_longitude > -73.8802 & dat$Dropoff_longitude < -73.8554  
     & dat$Dropoff_latitude > 40.7711 & dat$Dropoff_latitude < 40.7752)|
    (dat$Dropoff_longitude > -73.8678 & dat$Dropoff_longitude < -73.8554  
     & dat$Dropoff_latitude > 40.7691 & dat$Dropoff_latitude < 40.7752)|
    (dat$Dropoff_longitude > -73.8633 & dat$Dropoff_longitude < -73.8554  
     & dat$Dropoff_latitude > 40.7668 & dat$Dropoff_latitude < 40.7752)) 

# Number of trips originate or terminate at LGA
length(LGA_dropoff)
length(LGA_pickup)

# Unions of pickup and dropoff (avoid counting the same trip twice)
dat_LGA = dat[union(LGA_pickup, LGA_dropoff),]

# Plot points at LGA airport
plot(x=dat$Pickup_longitude[LGA_pickup], y=dat$Pickup_latitude[LGA_pickup], 
     main = 'Pickup Locations in LGA', 
     xlim = c(-73.8912,-73.8554), ylim = c(40.7660, 40.7752))
plot(x=dat$Dropoff_longitude[LGA_dropoff], y=dat$Dropoff_latitude[LGA_dropoff], 
     main = 'Dropoff Locations in LGA', 
     xlim = c(-73.8912,-73.8554), ylim = c(40.7660, 40.7752))




#  EWR  #



# The following are codes for EWR, similar to the two above
EWR_pickup = which(
  dat$Pickup_longitude > -74.187 & dat$Pickup_longitude < -74.174
  & dat$Pickup_latitude > 40.685 & dat$Pickup_latitude < 40.7)
EWR_dropoff = which(
  dat$Dropoff_longitude > -74.187 & dat$Dropoff_longitude < -74.174
  & dat$Dropoff_latitude > 40.685 & dat$Dropoff_latitude < 40.7)
length(EWR_dropoff)
length(EWR_pickup)
plot(x=dat$Pickup_longitude[EWR_pickup], y=dat$Pickup_latitude[EWR_pickup], 
     main = 'Pickup Locations in EWR',
     xlim = c(-74.187,-74.174), ylim = c(40.685, 40.7))
plot(x=dat$Dropoff_longitude[EWR_dropoff], y=dat$Dropoff_latitude[EWR_dropoff], 
     main = 'Dropoff Locations in EWR', 
     xlim = c(-74.187,-74.174), ylim = c(40.685, 40.7))



#  Results and other features #



#create a table for transaction to each airport
Airport_transaction <- data.frame(
  Airport =c('JFC', 'LGA', 'EWR'),
  Pickup = c(length(JFK_pickup), length(LGA_pickup), length(EWR_pickup)), 
  Dropoff = c(length(JFK_dropoff), length(LGA_dropoff), length(EWR_dropoff)), 
  All_transaction=c(length(union(JFK_pickup, JFK_dropoff)), 
                   length(union(LGA_pickup, LGA_dropoff)), 
                   length(union(EWR_pickup, EWR_dropoff))))
Airport_transaction 

#total counts
Airport_index= sort(unique(c(JFK_pickup, JFK_dropoff, LGA_pickup, LGA_dropoff, 
                     EWR_pickup, EWR_dropoff)))
sum(length(Airport_index))

#proportion of airport trips
sum(length(Airport_index))/nrow(dat)*100

#proportion of dropoff trips at airports
Airport_dropoff_index = sort(unique(c(JFK_dropoff, LGA_dropoff, EWR_dropoff)))
sum(length(Airport_dropoff_index))/sum(length(Airport_index)) * 100

# mean total amount
mean(dat$Total_amount[Airport_index])
mean(dat$Total_amount)

# Number of Trips grouped by Pickup Hour
hist(dat$Pickup_hour[Airport_index],breaks = 24, xlim = c(0,23), 
     xlab = 'Pickup Hour', ylab =  'Count')

