library(readr)
library(ggplot2)



#load the data
dat <- read_csv('green_tripdata_2015-09.csv')

# Tip percentage
dat$Tip_percent = dat$Tip_amount/dat$Total_amount*100

# (1) delete empty column
dat$Ehail_fee <- NULL

# (2) create rowID
dat$ID <- 1:nrow(dat)

# (3) imputation for 'zero' location coordinates with mean
dat$Pickup_longitude[dat$Pickup_longitude==0] = mean(dat$Pickup_longitude)
dat$Dropoff_longitude[dat$Dropoff_longitude==0] = mean(dat$Dropoff_longitude)
dat$Pickup_latitude[dat$Pickup_latitude==0] = mean(dat$Pickup_latitude)
dat$Dropoff_latitude[dat$Dropoff_latitude==0] = mean(dat$Dropoff_latitude)


# (4) delete transactions with zero total_amount and non-credit-card payment type
dat1 <- dat[dat$Total_amount>0, ] 
dat1 <- dat1[dat1$Payment_type == 1, ] 


dat1$Trip_type[is.na(dat1$Trip_type)] <- 2 # fill the missing value

# Only take a small sample to examine the feature faster and more clearly
set.seed(1)
temp_idx = sample(1:nrow(dat1), 20000, replace = F)


###  Location  ###
Pickup_coordinates <- dat1[, c('Pickup_longitude', 'Pickup_latitude')]
Pickup_km <- kmeans(Pickup_coordinates, 15, nstart=10)
plot(Pickup_coordinates, col=(Pickup_km$cluster),
     main="K-Means Clustering for Pickup Locations", xlab="Pickup Locations",
     xlim=c(-74.1,-73.7), ylim=c(40.55,40.95), pch=20, cex=.8)

Dropoff_coordinates <- dat1[, c('Dropoff_longitude', 'Dropoff_latitude')]
Dropoff_km <- kmeans(Dropoff_coordinates, 15, nstart=10)
plot(Dropoff_coordinates, col=(Dropoff_km$cluster),
     main="K-Means Clustering for Dropoff Locations", xlab="Dropoff Locations",
     xlim=c(-74.1,-73.7), ylim=c(40.55,40.95), pch=20, cex=.8)
Clusters <- model.matrix(
  y ~ pickup + dropoff, 
  data = data.frame(y=rep(1, nrow(dat1)), pickup=factor(Pickup_km$cluster),
                    dropoff=factor(Dropoff_km$cluster)))[,-1]

dat1 = cbind(dat1, Clusters)

pickup_time <- as.POSIXct(dat1$lpep_pickup_datetime, 
                          format='%Y-%m-%d %H:%M:%S')
dat1$Pickup_hour <- as.numeric(format(pickup_time, '%H'))
dat1$Pickup_day <- as.numeric(format(pickup_time, '%d'))
dat1$Pickup_day_of_week <- dat1$Pickup_day %% 7 + 1
dat1$Pickup_weekend <- floor(dat1$Pickup_day_of_week / 6)

dropoff_time <- as.POSIXct(dat1$Lpep_dropoff_datetime, 
                           format='%Y-%m-%d %H:%M:%S')
dat1$Dropoff_hour <- as.numeric(format(dropoff_time, '%H'))
dat1$Dropoff_day <- as.numeric(format(dropoff_time, '%d'))
dat1$Dropoff_day_of_week <- dat1$Dropoff_day %% 7 + 1
dat1$Dropoff_weekend <- floor(dat1$Dropoff_day_of_week / 6)

dat1$Duration_min <- round((as.vector(dropoff_time) 
                            - as.vector(pickup_time))/60, 3)
dat1$Speed <- dat1$Trip_distance / dat1$Duration_min
dat1$Speed[dat1$Duration_min==0] = 0

dat1$Pickup_morning <- as.numeric(dat1$Pickup_hour > 4 & dat1$Pickup_hour <= 9)
dat1$Pickup_daytime <- as.numeric(dat1$Pickup_hour > 9 & dat1$Pickup_hour <= 18)
dat1$Pickup_evening <- as.numeric(dat1$Pickup_hour > 18 & dat1$Pickup_hour < 24)
dat1$Pickup_night <- as.numeric(dat1$Pickup_hour >= 0 & dat1$Pickup_hour < 4)
dat1$Dropoff_morning <- as.numeric(dat1$Dropoff_hour > 4 & dat1$Dropoff_hour <= 9)
dat1$Dropoff_daytime <- as.numeric(dat1$Dropoff_hour > 9 & dat1$Dropoff_hour <= 18)
dat1$Dropoff_evening <- as.numeric(dat1$Dropoff_hour > 18 & dat1$Dropoff_hour < 24)
dat1$Dropoff_night <- as.numeric(dat1$Dropoff_hour >= 0 & dat1$Dropoff_hour < 4)

dat1$Coordinate_dist <- apply(
  dat1[, c('Pickup_longitude', 'Pickup_latitude', 
           'Dropoff_longitude', 'Dropoff_latitude')], 
  1, function(x){geosphere::distHaversine(x[1:2], x[3:4])})/1609.344 # mile
dat1$Tip_percent_class <- cut(dat1$Tip_percent,
                              c(-1,5.362, 13.69533, 18.33333, 21.53846,100),
                              labels = c(0,10.724,16.6667,20,23.0769))
names(dat1)

write.table(dat1, file = 'dat1.csv', row.names = F, sep = ',')

