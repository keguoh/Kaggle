library(randomForest)
library(caret)
library(parallel)
library(doParallel)
library(pROC)

set.seed(1000)

trn_idx <- sample(1:nrow(dat1), nrow(dat1)/3*2, replace = F)
trn <- dat1[trn_idx, ]
tst <- dat1[-trn_idx, ]

mae <- function(x,y) mean(abs(x-y))



# trnfm <- subset(trn, select=-c(Tip_percent, Total_amount, lpep_pickup_datetime,
#                                Lpep_dropoff_datetime, ID, Tip_amount,
#                                payment_type))
# tstfm <- subset(tst, select=-c(Tip_percent, Total_amount, lpep_pickup_datetime,
#                                Lpep_dropoff_datetime, ID, Tip_amount,
#                                payment_type))

trnfm <- trn[,c('Dropoff_longitude','Pickup_longitude','Dropoff_latitude',
                'Pickup_latitude','Pickup_day','Fare_amount','Passenger_count',
                'Trip_distance','Coordinate_dist','Pickup_day_of_week',
                'Duration_min','Speed','Pickup_hour','Dropoff_hour','Extra',
                'Pickup_weekend','VendorID','Pickup_morning','Pickup_daytime',
                'Pickup_evening','Dropoff_morning','Dropoff_daytime','Dropoff_evening',
                'pickup12','dropoff7','pickup4','pickup7', 'Tip_percent_class')]
tstfm <- tst[,c('Dropoff_longitude','Pickup_longitude','Dropoff_latitude',
                'Pickup_latitude','Pickup_day','Fare_amount','Passenger_count',
                'Trip_distance','Coordinate_dist','Pickup_day_of_week',
                'Duration_min','Speed','Pickup_hour','Dropoff_hour','Extra',
                'Pickup_weekend','VendorID','Pickup_morning','Pickup_daytime',
                'Pickup_evening','Dropoff_morning','Dropoff_daytime','Dropoff_evening',
                'pickup12','dropoff7','pickup4','pickup7', 'Tip_percent_class')]

system.time(
  rf_fit <- randomForest(Tip_percent_class ~ ., data=trnfm, ntree =500)
)
rf_fit$importance
pred <- as.numeric(paste(predict(rf_fit ,newdata = tstfm)))
mae(tst$Tip_percent, pred)   #4.86
rf_prob <- predict(rf_fit ,newdata = tstfm, type = 'prob')


# 
# trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, Payment_type, 
#                                  lpep_pickup_datetime, Lpep_dropoff_datetime, 
#                                  ID, Tip_amount))
# tstfm <- subset(tst, select = -c(Tip_percent, Total_amount, Payment_type, 
#                                  lpep_pickup_datetime, Lpep_dropoff_datetime, 
#                                  ID, Tip_amount))
# (no_cores <- detectCores())
# cl<-makeCluster(no_cores)
# registerDoParallel(cl)
# system.time(
#   rf_fit<-train(Tip_percent_class~., data=trnfm, method="rf",
#                   trControl=trainControl(method="cv",number=2),
#                   prox=TRUE,allowParallel=TRUE)
# )
# rf_fit$finalModel
# pred <- as.numeric(paste(predict(rf_fit ,newdata = tstfm)))
# rf_pred <- predict(rf_fit ,newdata = tstfm)
# mae(tst$Tip_percent, pred)   #4.754


write.table(cbind(tst$ID, pred, rf_prob),
            file="rf.csv", sep = ',', row.names = F)
