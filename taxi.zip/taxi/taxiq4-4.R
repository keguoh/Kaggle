library(nnet)
# Split the raw data into train and test dataset
set.seed(1)
trn_idx4 <- sample(1:nrow(dat1), nrow(dat4)/3*2, replace = F)
trn4 <- dat1[trn_idx4, ]
tst4 <- dat1[-trn_idx4, ]
#
set.seed(1)
temp <- sample(1:nrow(trn4), 9000, replace = F)
trn_temp = temp[1:6000]
val_temp = temp[-(1:6000)]


#MSE
# mse <- function(x,y) mean((x-y)^2)
mae <- function(x,y) mean(abs(x-y))
#Benchmark
tst$pred <- 50/3
# mse(tst$pred, tst$Tip_percent) # 67.65672
mae(tst$pred, tst$Tip_percent) # 4.865767
mae(rep(50/3,length(val_temp)), trn$Tip_percent[val_temp])  #4.659616

##################################
#####                        #####
#####  Random Forest (Tree)  #####
#####                        #####
##################################


# rf + caret
library(randomForest)
library(caret)

trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, Payment_type, 
                                 lpep_pickup_datetime, Lpep_dropoff_datetime, 
                                 ID, Tip_amount))
(no_cores <- detectCores())
cl<-makeCluster(no_cores)
registerDoParallel(cl)
system.time(
  rf_model<-train(Tip_percent_class~., data=trnfm[trn_temp, ], method="rf",
                trControl=trainControl(method="cv",number=2),
                prox=TRUE,allowParallel=TRUE)

)
rf_model$finalModel
rf_pred <- as.numeric(paste(predict(rf_model ,newdata = trnfm[val_temp ,])))
rf_prob <- predict(rf_model ,newdata = trnfm[val_temp ,])



## rf
# 
# trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, Payment_type, 
#                                  lpep_pickup_datetime, Lpep_dropoff_datetime, 
#                                  ID, Tip_amount))
# 
# system.time(
#   expr = rf_fit <- randomForest(Tip_percent_class ~ ., data=trnfm[trn_temp, ], ntree =100)
# )
# rf_fit$importance
# rf_pred <- as.numeric(paste(predict(rf_fit ,newdata = trnfm[val_temp ,])))
# mae(trn$Tip_percent[val_temp], rf_pred)   #4.86
# 


#################################
#####                       #####
#####  Nearest neighbour    #####
#####                       #####
#################################
trnfm <- trn[,c('Dropoff_longitude', 'Dropoff_latitude', 'Tip_percent_class')]  #5.25, 5.216, k=20
# 
# trnfm <- trn[,c('Pickup_longitude', 'Pickup_latitude', 'Tip_percent_class')]  #5.04, 6.21, k=20
# 
# trnfm <- trn[,c('Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
#                 'Dropoff_latitude', 'Tip_percent_class')]  #5.01, 5.26, k=20
# 
# trnfm <- trn[,c('Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
#                 'Dropoff_latitude', 'Pickup_day', 'Fare_amount', 'Tip_percent_class')]   #5.06, 5.038, k=20
# 
# trnfm <- trn[,c('Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
#                 'Dropoff_latitude', 'Pickup_day', 'Fare_amount',
#                 'Passenger_count', 'Pickup_hour', 'Coordinate_dist',
#                 'Speed', 'Tip_percent_class')]   #5.07, 5.04, k=20
trnfm <- subset(trn, select = -c(Coordinate_dist,Tip_percent, Total_amount, 
                                 RateCodeID, Store_and_fwd_flag, Payment_type,
                                 lpep_pickup_datetime, improvement_surcharge,
                                 MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount)) # 4.996, 4.937
# kknn
install.packages('kknn')
library(kknn)
kknn_fit <- kknn(Tip_percent_class ~ ., trnfm[trn_temp, ], trnfm[val_temp, ], distance = 1,
kernel = "triangular")
kknn_pred <- as.numeric(paste(kknn_fit$fitted.values))
mae(trn$Tip_percent[val_temp], kknn_pred)  

# knn
library(class)
set.seed(1)
system.time(
  knn_fit <- knn(
    scale(trnfm[trn_temp,-ncol(trnfm)]), 
    scale(trnfm[val_temp,-ncol(trnfm)]), 
    trnfm[trn_temp,ncol(trnfm)], k=20, prob = T)
)
knn_pred <- as.numeric(paste(knn_fit))
mae(trn$Tip_percent[val_temp], knn_pred)  


#cross validation
cv_knn <- function(t){
  mae <- function(x,y) mean(abs(x-y))
  k1=1
  folds=sample(1:k1,length(trn_temp),replace=TRUE)
  error <- rep(0,k1)
  for(i in 1:k1){
    knn_fit <- class::knn(scale(trnfm[folds!=i,-ncol(trnfm)]), 
                          scale(trnfm[folds==i,-ncol(trnfm)]), 
                          trnfm[folds!=i,ncol(trnfm)], k=t)
    knn_pred <- as.numeric(paste(knn_fit))
    error[i] <- mae(trn$Tip_percent[folds==i], knn_pred)
  }
  return(mean(error))
}
trial=1:2
(no_cores <- detectCores())
cl <- makeCluster(no_cores-2)
clusterExport(cl, c("trnfm", "trn_temp", "val_temp", "trn", "trial"))
te <- parLapply(cl, trial, cv_knn)
unlist(te)
stopCluster(cl)





#################################
#####                       #####
#####  C50 (Boosting Tree)  #####
#####                       #####
#################################



# install.packages("C50")
library(C50)
library(parallel)
trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, Payment_type, 
                                 lpep_pickup_datetime, Lpep_dropoff_datetime, 
                                 ID, Tip_amount))

cv_C50 <- function(t){
  mae <- function(x,y) mean(abs(x-y))
  k=2
  folds=sample(1:k,length(trn_temp),replace=TRUE)
  error <- rep(0,k)
  for(i in 1:k){
    C50_fit <- C50::C5.0(trnfm[folds!=i, -ncol(trnfm)],
                         trnfm[folds!=i, ncol(trnfm)], trial = t)
    C50_pred <- as.numeric(paste(
    C50::predict.C5.0(C50_fit, trnfm[folds==i, -ncol(trnfm)], type="class" )))
    error[i] <- mae(trn$Tip_percent[folds==i], C50_pred)
  }
  return(mean(error))
}
trial=1:3
(no_cores <- detectCores())
cl <- makeCluster(no_cores-1)
clusterExport(cl, c("trnfm", "trn_temp", "val_temp", "trn", "trial"))
te <- parLapply(cl, trial, cv_C50)
unlist(te)
stopCluster(cl)




C50_fit <- C5.0(trnfm[folds!=i, -ncol(trnfm)],
                         trnfm[folds!=i, ncol(trnfm)], trial = 20)
C50_pred <- as.numeric(paste(predict(C50_fit, trnfm[val_temp, -ncol(trnfm)], type="class" )))
C50_prob <- predict(C50_fit, trnfm[val_temp, -ncol(trnfm)], type="prob" )
(C50imp <- C5imp(C50_fit, metric = "splits", pct = TRUE))

mae(trn$Tip_percent[val_temp], C50_pred)   #5.04


##################################
#####                        #####
#####  LDA  #####
#####                        #####
##################################

library(MASS)
trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, Payment_type, lpep_pickup_datetime, improvement_surcharge, MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))

system.time(
  LDA_fit <- lda(Tip_percent_class ~ ., data = trnfm[trn_temp, ])
)
LDA_output <- predict(LDA_fit, trnfm[val_temp, ])
LDA_prob <- LDA_output$posterior
LDA_pred <- as.numeric(paste(LDA_output$class)) 
mae(trn$Tip_percent[val_temp], LDA_pred)   #4.754


system.time(
  QDA_fit <- qda(Tip_percent_class ~ ., data = trnfm[trn_temp, ])
)
QDA_output <- predict(QDA_fit, trnfm[val_temp, ])
QDA_prob <- QDA_output$posterior
QDA_pred <- as.numeric(paste(QDA_output$class)) 
mae(trn$Tip_percent[val_temp], QDA_pred)   #6.6889



#############################################
#####                                   #####
#####  Multinomial Logistic Regression  #####
#####                                   #####
#############################################



trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, Payment_type, lpep_pickup_datetime, improvement_surcharge, MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))

library(glmnet)
install.packages('doMC')
library(doMC)
registerDoMC(cores=3)

library(parallel)
(no_cores <- detectCores())
cl <- makeCluster(no_cores-1)
system.time(
  mlog_fit <- cv.glmnet(as.matrix(trnfm[trn_temp, -ncol(trnfm)]), 
                        trnfm[trn_temp, ncol(trnfm)], nfolds = 3, type.measure = 'mae',
                        parallel = T, family = 'multinomial')
)
plot(mlog_fit)

mlog_pred <- as.numeric(paste(predict(mlog_fit, newx = as.matrix(trnfm[val_temp, !colnames(trnfm)%in%c('Tip_percent_class')]),
                    type = "class")))
mlog_out <- predict(mlog_fit, newx = as.matrix(trnfm[val_temp, !colnames(trnfm)%in%c('Tip_percent_class')]),
                    type = "response")
mlog_prob <- as.numeric(paste(mlog_out))
head(mlog_prob)
mae(trn$Tip_percent[val_temp], mlog_pred)    #4.725358

x=1

# http://www.ats.ucla.edu/stat/r/dae/mlogit.htm

library(nnet)
trnfm4 <- subset(trn4, select = -c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, Payment_type, lpep_pickup_datetime, improvement_surcharge, MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))

system.time(
  mlognnet_fit <- multinom(Tip_percent_class ~ ., data = trnfm4[trn_temp, ])
)
s <- summary(mlognnet_fit)
z <- s$coefficients/s$standard.errors
(p <- (1 - pnorm(abs(z), 0, 1))*2)
mlognnet_prob <- predict(mlognnet_fit, newdata = trnfm4[val_temp, ], "probs")
mlognnet_prob_max <- apply(mlognnet_prob, 1, max)
mlognnet_pred <- as.numeric(colnames(mlognnet_prob)[apply(mlognnet_prob, 1, which.max)])

write.table(cbind(mlognnet_prob, mlognnet_pred, trnfm$VendorID[val_temp]),'test.csv', sep = ',', row.names = F)
mae(trn$Tip_percent[val_temp], mlognnet_pred)


# Testing ................
# set.seed(10000)
# temp <- sample(1:nrow(trn), 90000, replace = F)
# trn_temp = temp[1:60000]
# val_temp = temp[-(1:60000)]
# 
# trnfm <- subset(trn, select=-c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, 
#                                Payment_type, lpep_pickup_datetime, improvement_surcharge, 
#                                MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))
# trnfm <- subset(trn, select=-c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, 
#                                Payment_type, lpep_pickup_datetime, improvement_surcharge, 
#                                MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount, Passenger_count,
#                                Pickup_hour, Pickup_day, Pickup_day_of_week, Pickup_weekend,
#                                Dropoff_day, Dropoff_day_of_week, Dropoff_weekend, Speed, Coordinate_dist))
# 
# system.time(
#   mlognnet_fit <- multinom(Tip_percent_class ~ ., data = trnfm[trn_temp, ])
# )
# s <- summary(mlognnet_fit)
# z <- s$coefficients/s$standard.errors
# (p <- (1 - pnorm(abs(z), 0, 1))*2)
# mlognnet_prob <- predict(mlognnet_fit, newdata = trnfm[val_temp, ], "probs")
# mlognnet_prob_max <- apply(mlognnet_prob, 1, max)
# mlognnet_pred <- as.numeric(colnames(mlognnet_prob)[apply(mlognnet_prob, 1, which.max)])
# 
# 
# mae(trn$Tip_percent[val_temp], mlognnet_pred)    
# 
# 
# #  All                  sig
# #  4.747407           4.742672
# #  4.728288          4.725669




#Based on MAE, we use center as the output of each class
#     center      mean  
#MSE  65.89208   65.00713
#MAE  4.804828   4.842471
#     67.291    66.41646
#     4.826      4.862644


##################################
#####                        #####
#####  SVM  #####
#####                        #####
##################################

install.packages('e1071')
library(e1071)
trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, Payment_type, lpep_pickup_datetime, improvement_surcharge, MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))

svm_fit =svm(Tip_percent_class ~ ., data = trnfm[trn_temp, ], kernel ="linear", cost =10,
             scale =F )

######################################
#####                            #####
#####  Regression (Lasso/Ridge)  #####
#####                            #####
######################################
install.packages('glmnet')
library(glmnet)
trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, RateCodeID, Payment_type, Store_and_fwd_flag, lpep_pickup_datetime, Lpep_dropoff_datetime, ID, Tip_percent_class))

grid =10^seq(10,-2, length =100)
Ridge_fit <- glmnet(as.matrix(trnfm[trn_temp,-10]), trnfm[trn_temp,10],
                    alpha =0, lambda =grid ,thresh =1e-12)
Ridge_amount_pred <- predict(Ridge_fit, s=100, newx=as.matrix(trnfm[val_temp,-10]))
Ridge_pred <- as.vector(Ridge_amount_pred) / (
  as.vector(Ridge_amount_pred) + trnfm$Tolls_amount[val_temp] + trnfm$MTA_tax[val_temp] + 
    trnfm$improvement_surcharge[val_temp] + trnfm$MTA_tax[val_temp] + 
    trnfm$Fare_amount[val_temp] + trnfm$Extra[val_temp]
)
mae(trn$Tip_percent[val_temp], Ridge_pred)   #4.86


#################################
#####                       #####
#####  Logistic Regression  #####
#####                       #####
#################################
 

drop <- c('Total_amount', 'RateCodeID', 'Store_and_fwd_flag', 'Payment_type', 'lpep_pickup_datetime', 'improvement_surcharge', 'MTA_tax', 'Lpep_dropoff_datetime','ID', 'Tip_amount')

trnfm <- subset(trn, select = -c(Total_amount, RateCodeID, Store_and_fwd_flag, Payment_type, lpep_pickup_datetime, improvement_surcharge, MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))
trnfm <- subset(tst, select = -c(Total_amount, RateCodeID, Store_and_fwd_flag, Payment_type, lpep_pickup_datetime, improvement_surcharge, MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))

# trnfm <- subset(trn, select=-c(RateCodeID, Store_and_fwd_flag, 
#                                Payment_type, lpep_pickup_datetime, 
#                                Lpep_dropoff_datetime, ID, Tip_amount, 
#                                Fare_amount, Extra, MTA_tax, 
#                                improvement_surcharge, Tolls_amount))
# trnfm <- subset(tst, select=-c(RateCodeID, Store_and_fwd_flag, 
#                                 Payment_type, lpep_pickup_datetime, 
#                                 Lpep_dropoff_datetime, ID, Tip_amount))

# paste(names(trnfm)[ !names(trnfm)%in%drop], collapse='+')
# 
# VendorID+Pickup_longitude+Pickup_latitude+Dropoff_longitude+Dropoff_latitude+
#   Passenger_count+Trip_distance+Fare_amount+Extra+Tolls_amount+
#   Trip_type+Pickup_hour+Pickup_day+Pickup_day_of_week+Pickup_weekend+
#   Dropoff_hour+Dropoff_day+Dropoff_day_of_week+Dropoff_weekend+Duration_min+
#   Speed+Tip_percent
# 
log_fit=glm(Tip_percent/100 ~ ., data=trnfm, family=quasibinomial)
# log_fit=glm(Tip_amount/Total_amount ~ ., data=trnfm[trn_temp,], family=binomial)
# log_fit=glm(Tip_percent/100 ~ ., data=trnfm[trn_temp,], family=binomial)
# log_fit=glm(Tip_percent/100 ~ ., data=trnfm[trn_temp,], weights = trnfm$Total_amount[trn_temp],family=binomial)
# 
# log_fit=glm(Tip_amount/(Tip_amount+Fare_amount+Extra+MTA_tax+
#                           improvement_surcharge+Tolls_amount) ~ .,
#             data=trnfm[trn_temp,], family=binomial)
# 
# log_fit=glm(Tip_percent/100 ~ VendorID+Pickup_longitude+Pickup_latitude+
#               Dropoff_longitude+Dropoff_latitude+Passenger_count+Trip_distance+
#               Fare_amount+Extra+Tolls_amount+Trip_type+Dropoff_hour+
#               Duration_min+Speed, data=trnfm, family=quasibinomial)
summary(log_fit)

log_pred=predict(log_fit,trnfm[val_temp,],type="response")
sum(is.nan(log_pred))
mse(tst$Tip_percent[val_temp], log_pred*100)  #59.55861
mae(tst$Tip_percent[val_temp], log_pred*100)  #5.4328



# Histogram of Tip Percent
hist(trn1$Tip_percent, xlim = c(0,40), breaks = 100)
mean(trn1$Tip_percent)

sum(trn1$Tip_percent==0)/nrow(trn1)
hist(trn1$Tip_percent, xlim = c(0.1,.4), breaks = 100)

temp <- trn1[sample(1:nrow(trn1), 10000, replace = F), ]


k=5
set.seed(1)
folds=sample(1:k,nrow(trn),replace=TRUE)
cv.errors=matrix(NA,k,19, dimnames=list(NULL, paste(1:19)))
for(j in 1:k){                           #There were not typos, you just need to run all the data 
  best.fit=regsubsets(Salary~.,data=Hitters[folds!=j,],nvmax=19)
  for(i in 1:19){
    pred=predict(best.fit,Hitters[folds==j,],id=i)
    cv.errors[j,i]=mean((Hitters$Salary[folds==j]-pred)^2)
  }
}
mean.cv.errors=apply(cv.errors,2,mean)
mean.cv.errors
par(mfrow=c(1,1))
plot(mean.cv.errors,type='b')


#CV
# k=10
# set.seed(1)
# folds=sample(1:k,nrow(Hitters),replace=TRUE)
# cv.errors=matrix(NA,k,19, dimnames=list(NULL, paste(1:19)))
# for(j in 1:k){                           #There were not typos, you just need to run all the data 
#   best.fit=regsubsets(Salary~.,data=Hitters[folds!=j,],nvmax=19)
#   for(i in 1:19){
#     pred=predict(best.fit,Hitters[folds==j,],id=i)
#     cv.errors[j,i]=mean((Hitters$Salary[folds==j]-pred)^2)
#   }
# }
# mean.cv.errors=apply(cv.errors,2,mean)
# mean.cv.errors
# par(mfrow=c(1,1))
# plot(mean.cv.errors,type='b')

