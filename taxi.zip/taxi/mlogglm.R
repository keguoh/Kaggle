library(glmnet)
library(parallel)
library(doParallel)
set.seed(1000)
trn_idx <- sample(1:nrow(dat1), nrow(dat1)/3*2, replace = F)
trn <- dat1[trn_idx, ]
tst <- dat1[-trn_idx, ]

#MSE
mae <- function(x,y) mean(abs(x-y))
#Benchmark
tst$pred <- 50/3
(mae(tst$pred, tst$Tip_percent)) # 4.865767


trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, Payment_type, lpep_pickup_datetime, improvement_surcharge, MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))
tstfm <- subset(tst, select = -c(Tip_percent, Total_amount, RateCodeID, Store_and_fwd_flag, Payment_type, lpep_pickup_datetime, improvement_surcharge, MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount))

(no_cores <- detectCores())
cl<-makeCluster(no_cores-1)
registerDoParallel(cl)
system.time(
  mlogglm_fit <- cv.glmnet(as.matrix(trnfm[, -ncol(trnfm)]), 
                        trnfm[, ncol(trnfm)], nfolds = 3, type.measure = 'mae',
                        parallel = T, family = 'multinomial')
)
plot(mlogglm_fit)
save.image()
pred <- as.numeric(paste(
  predict(mlogglm_fit, 
          newx = as.matrix(tstfm[, !colnames(tstfm)=='Tip_percent_class']),
          type = "class")))
mlogglm_out <- predict(mlogglm_fit, 
                       newx = as.matrix(tstfm[, !colnames(trnfm)%in%c('Tip_percent_class')]),
                       type = "response")
mlogglm_out <- as.data.frame(mlogglm_out)
colnames(mlogglm_out) <- c('0.1', '10.724', '16.6667', '20', '23.0769')

mae(tst$Tip_percent, pred)    #4.725358

write.table(cbind(tst$ID, pred, mlogglm_out),
            file="mlogglm.csv", sep = ',', row.names = F)
stopCluster(cl)
