library(nnet)
set.seed(1000)
trn_idx <- sample(1:nrow(dat1), nrow(dat1)/3*2, replace = F)
trn <- dat1[trn_idx, ]
tst <- dat1[-trn_idx, ]

mae <- function(x,y) mean(abs(x-y))

# trnfm <- subset(trn, select = -c(Tip_percent, Total_amount, lpep_pickup_datetime, Lpep_dropoff_datetime, ID, Tip_amount))
# tstfm <- subset(tst, select = -c(Tip_percent, Total_amount, lpep_pickup_datetime, Lpep_dropoff_datetime, ID, Tip_amount))

trnfm <- trn[,c('Dropoff_longitude','Pickup_longitude','Dropoff_latitude',
                'Pickup_latitude','Pickup_day','Fare_amount','Passenger_count',
                'Trip_distance','Coordinate_dist','Pickup_day_of_week',
                'Duration_min','Speed','Pickup_hour','Dropoff_hour','Extra',
                'Pickup_weekend','VendorID','Pickup_morning','Pickup_daytime',
                'Pickup_evening', 'Tip_percent_class')]
tstfm <- tst[,c('Dropoff_longitude','Pickup_longitude','Dropoff_latitude',
                'Pickup_latitude','Pickup_day','Fare_amount','Passenger_count',
                'Trip_distance','Coordinate_dist','Pickup_day_of_week',
                'Duration_min','Speed','Pickup_hour','Dropoff_hour','Extra',
                'Pickup_weekend','VendorID','Pickup_morning','Pickup_daytime',
                'Pickup_evening', 'Tip_percent_class')]

# trnfm <- trn[,c('Dropoff_longitude','Pickup_longitude','Dropoff_latitude',
#                 'Pickup_latitude','Pickup_day','Fare_amount','Passenger_count',
#                 'Trip_distance','Coordinate_dist','Pickup_day_of_week',
#                 'Duration_min','Speed','Pickup_hour','Dropoff_hour','Extra',
#                 'Pickup_weekend','VendorID','Pickup_morning','Pickup_daytime',
#                 'Pickup_evening','Dropoff_morning','Dropoff_daytime','Dropoff_evening',
#                 'pickup12','dropoff7','pickup4','pickup7', 'Tip_percent_class')]
# tstfm <- tst[,c('Dropoff_longitude','Pickup_longitude','Dropoff_latitude',
#                 'Pickup_latitude','Pickup_day','Fare_amount','Passenger_count',
#                 'Trip_distance','Coordinate_dist','Pickup_day_of_week',
#                 'Duration_min','Speed','Pickup_hour','Dropoff_hour','Extra',
#                 'Pickup_weekend','VendorID','Pickup_morning','Pickup_daytime',
#                 'Pickup_evening','Dropoff_morning','Dropoff_daytime','Dropoff_evening',
#                 'pickup12','dropoff7','pickup4','pickup7', 'Tip_percent_class')]

mlog_fit <- multinom(Tip_percent_class ~ ., data = trnfm)
save.image()
s <- summary(mlog_fit)
z <- s$coefficients/s$standard.errors
(p <- (1 - pnorm(abs(z), 0, 1))*2)
mlog_prob <- predict(mlog_fit, newdata = tstfm, "probs")
pred <- as.numeric(colnames(mlog_prob)[apply(mlog_prob, 1, which.max)])
mlog_prob_max <- apply(mlog_prob, 1, max)

(mae(tst$Tip_percent, pred))



# write.table(cbind(tst$ID, pred, mlog_prob),
#             file="mlognnet.csv", sep = ',', row.names = F)
