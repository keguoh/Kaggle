library(kknn)
library(parallel)
set.seed(1000)
trn_idx <- sample(1:nrow(dat1), nrow(dat1)/3*2, replace = F)
trn <- dat1[trn_idx, ]
tst <- dat1[-trn_idx, ]

trnfm <- trn[,c(
  'Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
  'Dropoff_latitude', 'Pickup_day', 'Fare_amount', 'Trip_distance',
  'Duration_min', 'Passenger_count', 'Pickup_hour', 'Coordinate_dist',
  'Speed', 'Pickup_day_of_week', 'Dropoff_hour', 'Extra', 'Pickup_weekend',
  'VendorID', 'Pickup_morning', 'Pickup_daytime',  'Tip_percent_class')
  ]
tstfm <- tst[,c(
  'Pickup_longitude', 'Pickup_latitude', 'Dropoff_longitude',
  'Dropoff_latitude', 'Pickup_day', 'Fare_amount', 'Trip_distance',
  'Duration_min', 'Passenger_count', 'Pickup_hour', 'Coordinate_dist',
  'Speed', 'Pickup_day_of_week', 'Dropoff_hour', 'Extra', 'Pickup_weekend',
  'VendorID', 'Pickup_morning', 'Pickup_daytime',  'Tip_percent_class')
  ]


cv_kknn <- function(t){
  mae <- function(x,y) mean(abs(x-y))
  total_fold=1
  folds=sample(1:total_fold,row(trn),replace=TRUE)
  error <- rep(0,total_fold)
  for(i in 1:total_fold){
    kknn_fit <- kknn::kknn(Tip_percent_class ~ ., trnfm[folds!=i,], trnfm[folds==i,], distance = 1)
    kknn_pred <- as.numeric(paste(kknn_fit$fitted.values))
    error[i] <- mae(trn$Tip_percent[folds==i], kknn_pred)
  }
  return(mean(error))
}
neigh=as.integer(seq(3,50,length.out = 16))
(no_cores <- detectCores())
cl <- makeCluster(no_cores)
clusterExport(cl, c("trnfm", "trn", "neigh"))
te <- parLapply(cl, neigh, cv_kknn)
unlist(te)
stopCluster(cl)

