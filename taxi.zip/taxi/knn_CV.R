library(class)
library(parallel)
set.seed(1000)
trn_idx <- sample(1:nrow(dat1), nrow(dat1)/3*2, replace = F)
trn <- dat1[trn_idx, ]
tst <- dat1[-trn_idx, ]

trnfm <- subset(trn, select = -c(Coordinate_dist,Tip_percent, Total_amount, 
                                 RateCodeID, Store_and_fwd_flag, Payment_type,
                                 lpep_pickup_datetime, improvement_surcharge,
                                 MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount)) # 4.996, 4.937
tstfm <- subset(tst, select = -c(Coordinate_dist,Tip_percent, Total_amount, 
                                 RateCodeID, Store_and_fwd_flag, Payment_type,
                                 lpep_pickup_datetime, improvement_surcharge,
                                 MTA_tax, Lpep_dropoff_datetime, ID, Tip_amount)) # 4.996, 4.937


cv_knn <- function(t){
  mae <- function(x,y) mean(abs(x-y))
  total_fold=1
  folds=sample(1:total_fold,row(trn),replace=TRUE)
  error <- rep(0,total_fold)
  for(i in 1:total_fold){
    knn_fit <- class::knn(scale(trnfm[folds!=i,-ncol(trnfm)]), 
                          scale(trnfm[folds==i,-ncol(trnfm)]), 
                          trnfm[folds!=i,ncol(trnfm)], k=t)
    knn_pred <- as.numeric(paste(knn_fit))
    error[i] <- mae(trn$Tip_percent[folds==i], knn_pred)
  }
  return(mean(error))
}
neigh=1:3
(no_cores <- detectCores()-1)
cl <- makeCluster(no_cores)
clusterExport(cl, c("trnfm", "trn", "neigh"))
te <- parLapply(cl, neigh, cv_knn)
unlist(te)
stopCluster(cl)

